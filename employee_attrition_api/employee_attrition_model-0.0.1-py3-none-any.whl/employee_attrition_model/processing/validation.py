import sys
from pathlib import Path
file = Path(__file__).resolve()
parent, root = file.parent, file.parents[1]
sys.path.append(str(root))

from typing import List, Optional, Tuple, Union,Any

from datetime import datetime
import numpy as np
import pandas as pd
from pydantic import BaseModel, ValidationError

from employee_attrition_model.config.core import config
from employee_attrition_model.processing.data_manager import pre_pipeline_preparation


def validate_inputs(*, input_df: pd.DataFrame) -> Tuple[pd.DataFrame, Optional[dict]]:
    """Check model inputs for unprocessable values."""

    pre_processed = pre_pipeline_preparation(data_frame = input_df)
    validated_data = pre_processed[config.model_config_.features].copy()
    errors = None

    try:
        # replace numpy nans so that pydantic can validate
        MultipleDataInputs(
            inputs = validated_data.replace({np.nan: None}).to_dict(orient="records")
        )
    except ValidationError as error:
        errors = error.json()

    return validated_data, errors


class DataInputSchema(BaseModel):
    age: Optional[Any] # This one already matches
    businesstravel: Optional[Any] # Change from business_travel
    dailyrate: Optional[Any] # Change from daily_rate
    department: Optional[Any] # Change from department if needed (check exact spelling)
    distancefromhome: Optional[Any] # Change from distance_from_home
    education: Optional[Any] # Change from education if needed
    educationfield: Optional[Any] # Change from education_field
    employeecount: Optional[Any] # Change from employee_count
    # Add fields present in your data but missing from your schema (e.g., employeenumber, over18)
    employeenumber: Optional[Any]
    environmentsatisfaction: Optional[Any] # Change from environment_satisfaction
    gender: Optional[Any] # Change from gender if needed
    hourlyrate: Optional[Any] # Change from hourly_rate
    jobinvolvement: Optional[Any] # Change from job_involvement
    joblevel: Optional[Any] # Change from job_level
    jobrole: Optional[Any] # Change from job_role
    jobsatisfaction: Optional[Any] # Change from job_satisfaction
    maritalstatus: Optional[Any] # Change from marital_status
    monthlyincome: Optional[Any] # Change from monthly_income
    monthlyrate: Optional[Any] # Change from monthly_rate
    numcompaniesworked: Optional[Any] # Change from num_companies_worked
    over18: Optional[Any] # Add this field
    overtime: Optional[Any] # Correct typo from over_time
    percentsalaryhike: Optional[Any] # Change from percent_salary_hike
    performancerating: Optional[Any] # Change from performance_rating
    relationshipsatisfaction: Optional[Any] # Change from relationship_satisfaction
    standardhours: Optional[Any] # Change from standard_hours
    stockoptionlevel: Optional[Any] # Change from stock_option_level
    totalworkingyears: Optional[Any] # Change from total_working_years
    trainingtimeslastyear: Optional[Any] # Change from training_times_last_year
    worklifebalance: Optional[Any] # Change from work_life_balance
    yearsatcompany: Optional[Any] # Correct typo from years_at_compAny
    yearsincurrentrole: Optional[Any] # Change from years_in_current_role
    yearssincelastpromotion: Optional[Any] 
    yearswithcurrmanager: Optional[Any] 
    
    


class MultipleDataInputs(BaseModel):
    inputs: List[DataInputSchema]